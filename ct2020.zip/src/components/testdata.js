const testdata = [
  {
    koodityyppi: "html",
    kooditunnit: 1,
    pvm: "01/06/2019",
    tehot: 0.4,
  },
  {
    koodityyppi: "css",
    kooditunnit: 4,
    pvm: "01/06/2019",
    tehot: 2,
  },
  {
    koodityyppi: "js",
    kooditunnit: 1,
    pvm: "01/06/2019",
    tehot: 0.7,
  },
  {
    koodityyppi: "React",
    kooditunnit: 8,
    pvm: "01/06/2014",
    tehot: 2,
  },
  {
    koodityyppi: "Git",
    kooditunnit: 8,
    pvm: "01/06/2019",
    tehot: 4,
  },
];

export default testdata;
