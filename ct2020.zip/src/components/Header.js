import  React from 'react';
import './header.css';

function Header(props) {

    return(
      <React.Fragment >
      <link href="https://fonts.googleapis.com/css?family=Orbitron" rel="stylesheet" />
      <header className="App-header"> 
      <h1><span id="spanni"> &#47;&#47;</span> C0DE TRACK<span id="spanni">&#123;</span>R</h1>    
      </header>
      </React.Fragment>
      );
          }
  
  
  
export default Header;