import React from 'react'
import {BrowserRouter as Router, Route,Link} from 'react-router-dom';
import './content.css'

function Content (props){

    return(
        
     <div>Contnet</div>      
    );
}

export default Content;